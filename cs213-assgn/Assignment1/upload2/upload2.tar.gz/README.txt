Ass1 Q1
No help taken from anywhere except how to use stl lists. 
Found this particularly useful http://www.cs.uregina.ca/Links/class-info/210/STLList/