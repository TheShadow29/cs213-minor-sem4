Ass1 Q1
No help taken for any question except the cyclic one. 
Found this link useful: https://www.quora.com/How-does-Floyds-cycle-finding-algorithm-work